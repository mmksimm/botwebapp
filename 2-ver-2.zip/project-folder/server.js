
const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

const db = new sqlite3.Database('./database.sqlite');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    level INTEGER DEFAULT 1,
    tokens INTEGER DEFAULT 0,
    seeds INTEGER DEFAULT 0
  )`);
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Имя пользователя и пароль обязательны.' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  db.run(`INSERT INTO users (username, password) VALUES (?, ?)`, [username, hashedPassword], function (err) {
    if (err) {
      return res.status(400).json({ error: 'Пользователь с таким именем уже существует.' });
    }
    db.get(`SELECT * FROM users WHERE id = ?`, [this.lastID], (err, row) => {
      if (err) {
        return res.status(500).json({ error: 'Ошибка сервера.' });
      }
      res.json(row);
    });
  });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Имя пользователя и пароль обязательны.' });
  }

  db.get(`SELECT * FROM users WHERE username = ?`, [username], (err, row) => {
    if (err || !row || !bcrypt.compareSync(password, row.password)) {
      return res.status(400).json({ error: 'Неверное имя пользователя или пароль.' });
    }
    res.json(row);
  });
});

app.post('/user', (req, res) => {
  const { id, tokens, seeds } = req.body;
  db.run(`UPDATE users SET tokens = ?, seeds = ? WHERE id = ?`, [tokens, seeds, id], err => {
    if (err) {
      return res.status(500).json({ error: 'Ошибка сервера.' });
    }
    res.status(200).send();
  });
});

app.listen(port, () => {
  console.log(`Сервер запущен на порту ${port}`);
});
    